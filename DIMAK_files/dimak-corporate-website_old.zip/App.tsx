import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Stats from './components/Stats';
import Services from './components/Services';
import Team from './components/Team';
import Affiliates from './components/Affiliates';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans selection:bg-dimak-red selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Stats />
        <Services />
        <Team />
        <Affiliates />
      </main>
      <Contact />
    </div>
  );
}

export default App;