import React from 'react';
import { Eye, Flag, Target, Users } from 'lucide-react';
import { CORE_VALUES } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        
        {/* Intro */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6 border-b-4 border-dimak-gold inline-block pb-2">
              About Us
            </h2>
            <p className="text-gray-700 leading-relaxed mb-6 text-lg">
              Incorporated in 2021, <strong>DIMAK</strong> is an integrated consulting outfit providing a wide range of professional services. 
              Our professionals and staff are stationed in all the firm's offices in Lagos, Abuja, Ilorin, and Kano, alongside global 
              associates & affiliates poised to deliver our trademark satisfaction and value addition.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Our team of seasoned professionals delivers end-to-end solutions comprising accountants, tax experts, auditors, engineers, 
              valuers, lawyers, immigration experts, and a host of other associates.
            </p>
          </div>
          
          <div className="flex flex-col gap-6">
            {/* Vision Card */}
            <div className="flex items-start bg-dimak-red text-white p-6 rounded-xl shadow-xl transform hover:-translate-y-1 transition-transform">
              <div className="bg-white/20 p-3 rounded-full mr-4">
                <Eye className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Our Vision</h3>
                <p className="opacity-90">To be a trusted global consulting partner, driving ethical and impactful growth.</p>
              </div>
            </div>

            {/* Mission Card */}
            <div className="flex items-start bg-dimak-red text-white p-6 rounded-xl shadow-xl transform hover:-translate-y-1 transition-transform">
              <div className="bg-white/20 p-3 rounded-full mr-4">
                <Flag className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Our Mission</h3>
                <p className="opacity-90">Delivering services with integrity, precision, and global best practices.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Core Values */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Core Values</h2>
            <div className="w-20 h-1 bg-dimak-red mx-auto mt-4"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {CORE_VALUES.map((val) => (
              <div key={val.id} className="bg-gray-50 p-8 rounded-lg border-t-4 border-dimak-red shadow-md hover:shadow-lg transition-shadow relative overflow-hidden group">
                 <div className="absolute -right-4 -top-4 text-9xl font-black text-gray-200 opacity-20 group-hover:text-dimak-red group-hover:opacity-10 transition-colors">
                  {val.id}
                </div>
                <div className="relative z-10">
                  <div className="mb-4">
                    {val.id === "01" && <Users className="w-10 h-10 text-dimak-red" />}
                    {val.id === "02" && <Target className="w-10 h-10 text-dimak-red" />}
                    {val.id === "03" && <Users className="w-10 h-10 text-dimak-red" />}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{val.title}</h3>
                  <p className="text-dimak-red font-medium mb-2">{val.subtitle}</p>
                  <p className="text-gray-600 text-sm">{val.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

export default About;