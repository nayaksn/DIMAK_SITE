import React from 'react';
import { AFFILIATES } from '../constants';
import { Network } from 'lucide-react';

const Affiliates: React.FC = () => {
  return (
    <section id="affiliates" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block p-3 bg-dimak-red/10 rounded-full mb-4">
            <Network className="w-8 h-8 text-dimak-red" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900">Affiliate Firms & Organizations</h2>
          <p className="text-gray-600 mt-2">Strong strategic partnerships driving global value.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {AFFILIATES.map((affiliate, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-sm border-l-4 border-dimak-red hover:shadow-md transition-shadow">
              <h3 className="text-xl font-bold text-gray-900 mb-3">{affiliate.name}</h3>
              <p className="text-gray-600">{affiliate.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Affiliates;