import React from 'react';
import { Mail, MapPin, Phone, Globe } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <footer id="contact" className="bg-dimak-dark text-white pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          
          {/* Brand & Message */}
          <div>
            <div className="flex items-center gap-2 mb-6">
               <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center border-2 border-dimak-red">
                  <span className="text-dimak-red font-bold text-xl">D</span>
               </div>
               <span className="text-2xl font-bold tracking-tight">DIMAK</span>
            </div>
            <h3 className="text-3xl font-bold mb-4">Ready to drive growth?</h3>
            <p className="text-gray-400 text-lg mb-8 max-w-md">
              Contact us today for a consultation. Our global team is ready to deliver value to your business.
            </p>
            <a 
              href={`mailto:${CONTACT_INFO.email}`} 
              className="inline-block bg-dimak-red hover:bg-red-600 text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Get in Touch
            </a>
          </div>

          {/* Contact Details */}
          <div className="bg-gray-800 p-8 rounded-2xl">
            <h4 className="text-xl font-bold text-dimak-gold mb-6">Contact Information</h4>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <MapPin className="w-6 h-6 text-dimak-red mr-4 flex-shrink-0 mt-1" />
                <div>
                  <p className="font-semibold text-white mb-1">Lagos Offices</p>
                  <p className="text-gray-400 text-sm mb-2">{CONTACT_INFO.addressLagos1}</p>
                  <p className="text-gray-400 text-sm">{CONTACT_INFO.addressLagos2}</p>
                </div>
              </div>

              <div className="flex items-start">
                <Globe className="w-6 h-6 text-dimak-red mr-4 flex-shrink-0 mt-1" />
                <div>
                    <p className="font-semibold text-white mb-1">Global Presence</p>
                    <p className="text-gray-400 text-sm">{CONTACT_INFO.globalLocations}</p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="w-6 h-6 text-dimak-red mr-4 flex-shrink-0 mt-1" />
                <div>
                   <p className="font-semibold text-white mb-1">Phone</p>
                   <div className="text-gray-400 text-sm flex flex-col sm:flex-row sm:gap-4">
                     {CONTACT_INFO.phones.map((phone, i) => (
                       <span key={i}>{phone}</span>
                     ))}
                   </div>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="w-6 h-6 text-dimak-red mr-4 flex-shrink-0 mt-1" />
                <div>
                    <p className="font-semibold text-white mb-1">Email</p>
                    <a href={`mailto:${CONTACT_INFO.email}`} className="text-gray-400 text-sm hover:text-white transition-colors">
                        {CONTACT_INFO.email}
                    </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Darubramha International Management and Konsulting Ltd. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Contact;