import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center bg-gray-50 overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-dimak-red/5 clip-diagonal hidden lg:block" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-dimak-gold/10 rounded-full blur-3xl" />

      <div className="container mx-auto px-6 relative z-10 pt-20">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="border-l-4 border-dimak-red pl-6 mb-8"
          >
             <h2 className="text-xl md:text-2xl font-bold text-dimak-red uppercase tracking-wide mb-2">
              Welcome to DIMAK
            </h2>
            <h1 className="text-4xl md:text-6xl font-extrabold text-gray-900 leading-tight">
              Darubramha International <br />
              Management and <span className="text-dimak-red">Konsulting</span> Ltd.
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="text-xl md:text-2xl text-gray-600 mb-10 font-light"
          >
            <span className="font-semibold text-dimak-gold">DELIVERING VALUE...</span>{' '}
            <span className="font-semibold text-dimak-red">DRIVING GROWTH...</span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <a 
              href="#services"
              className="inline-flex items-center justify-center px-8 py-4 bg-dimak-red text-white font-bold rounded-lg shadow-lg hover:bg-red-800 transition-colors group"
            >
              Our Services
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <a 
              href="#contact"
              className="inline-flex items-center justify-center px-8 py-4 bg-white text-dimak-red border-2 border-dimak-red font-bold rounded-lg shadow-sm hover:bg-red-50 transition-colors"
            >
              Contact Us
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;