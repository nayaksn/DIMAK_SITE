import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Team', href: '#team' },
    { name: 'Affiliates', href: '#affiliates' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-2 group">
             <div className="relative w-10 h-10">
                 <div className="absolute inset-0 bg-dimak-red rounded-l-full"></div>
                 <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-dimak-gold rounded-r-full"></div>
                 <div className="absolute inset-0 flex items-center justify-center text-white font-bold">D</div>
             </div>
             <div className="flex flex-col">
                <span className={`text-2xl font-bold tracking-tight ${scrolled ? 'text-gray-900' : 'text-gray-900'}`}>
                    DIMAK
                </span>
             </div>
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className={`font-medium text-sm uppercase tracking-wide hover:text-dimak-red transition-colors ${scrolled ? 'text-gray-700' : 'text-gray-800'}`}
            >
              {link.name}
            </a>
          ))}
          <a
             href="#contact"
             className="px-5 py-2 bg-dimak-red text-white rounded-full font-bold text-sm shadow hover:bg-red-800 transition-all"
          >
            Get Quote
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-gray-800 focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white absolute top-full left-0 w-full shadow-xl border-t border-gray-100">
          <div className="flex flex-col py-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-6 py-3 text-gray-800 hover:bg-gray-50 hover:text-dimak-red font-medium border-l-4 border-transparent hover:border-dimak-red transition-all"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;