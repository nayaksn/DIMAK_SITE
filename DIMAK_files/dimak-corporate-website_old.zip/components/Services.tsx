import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SERVICES } from '../constants';
import { CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';

const Services: React.FC = () => {
  const [openCategory, setOpenCategory] = useState<string | null>(SERVICES[0].category);

  const toggleCategory = (category: string) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive solutions across Accounting, Taxation, Audit, and Advisory to drive your business operational excellence.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {SERVICES.map((service, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-xl shadow-md overflow-hidden transition-all duration-300 ${openCategory === service.category ? 'ring-2 ring-dimak-red ring-opacity-50' : ''}`}
            >
              <button
                onClick={() => toggleCategory(service.category)}
                className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${openCategory === service.category ? 'bg-dimak-red text-white' : 'bg-gray-100 text-dimak-red'}`}>
                    {/* Simplified dynamic icon based on index/category logic could go here */}
                    <span className="font-bold text-lg">{index + 1}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{service.category}</h3>
                </div>
                {openCategory === service.category ? (
                  <ChevronUp className="w-6 h-6 text-gray-400" />
                ) : (
                  <ChevronDown className="w-6 h-6 text-gray-400" />
                )}
              </button>

              <AnimatePresence>
                {openCategory === service.category && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 pt-0 border-t border-gray-100">
                      <ul className="grid sm:grid-cols-1 gap-3 mt-4">
                        {service.items.map((item, i) => (
                          <li key={i} className="flex items-start text-gray-700 text-sm md:text-base">
                            <CheckCircle2 className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;