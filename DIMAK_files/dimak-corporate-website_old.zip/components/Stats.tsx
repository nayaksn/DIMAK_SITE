import React from 'react';

const Stats: React.FC = () => {
  const stats = [
    { label: "Leadership Experience", value: "40+", suffix: "Years" },
    { label: "Professionals", value: "75+", suffix: "Experts" },
    { label: "Global Network", value: "5+", suffix: "Continents" },
    { label: "Services", value: "100%", suffix: "Full-Spectrum" },
  ];

  return (
    <section className="py-20 bg-dimak-dark text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
        
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-6">Why Choose <span className="text-dimak-red">DIMAK</span>?</h2>
                <p className="text-gray-300 mb-6 text-lg">
                    We combine decades of leadership experience across Africa and beyond with a deep understanding of local markets and global standards.
                </p>
                <ul className="space-y-4">
                    <li className="flex items-center">
                        <span className="w-3 h-3 bg-dimak-gold rounded-full mr-3"></span>
                        Full-spectrum services: Tax, Audit, Legal, Advisory.
                    </li>
                    <li className="flex items-center">
                        <span className="w-3 h-3 bg-dimak-gold rounded-full mr-3"></span>
                        Proven results with diverse high-value clients.
                    </li>
                    <li className="flex items-center">
                        <span className="w-3 h-3 bg-dimak-gold rounded-full mr-3"></span>
                        Trusted affiliates & partners worldwide.
                    </li>
                </ul>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, idx) => (
                    <div key={idx} className="bg-white/10 backdrop-blur-sm p-6 rounded-xl border border-white/20 text-center hover:bg-white/20 transition-colors">
                        <div className="text-4xl font-bold text-dimak-gold mb-2">{stat.value}</div>
                        <div className="text-sm uppercase tracking-wider text-gray-400">{stat.suffix}</div>
                        <div className="text-white mt-1 font-medium">{stat.label}</div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </section>
  );
};

export default Stats;