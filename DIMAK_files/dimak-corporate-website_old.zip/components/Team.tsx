import React from 'react';
import { TEAM } from '../constants';
import { MapPin } from 'lucide-react';

const Team: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Leadership Team</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Led by veterans with decades of experience in finance, law, engineering, and management across the globe.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {TEAM.map((member, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100 overflow-hidden flex flex-col">
              <div className="h-48 bg-gray-200 relative overflow-hidden">
                <img 
                  src={`https://picsum.photos/seed/${member.name.replace(/ /g, '')}/400/300`} 
                  alt={member.name}
                  className="w-full h-full object-cover filter grayscale hover:grayscale-0 transition-all duration-500"
                />
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                    <p className="text-xs font-semibold bg-dimak-red px-2 py-1 rounded inline-block mb-1">
                        {member.role}
                    </p>
                </div>
              </div>
              
              <div className="p-6 flex-grow flex flex-col">
                <h3 className="text-xl font-bold text-gray-900 mb-1">{member.name}</h3>
                <p className="text-xs text-dimak-red font-bold mb-3 uppercase tracking-wider">{member.qualifications}</p>
                
                <p className="text-gray-600 text-sm mb-4 line-clamp-4 flex-grow">
                  {member.bio}
                </p>
                
                {member.location && (
                  <div className="flex items-center text-gray-400 text-xs mt-auto pt-4 border-t border-gray-100">
                    <MapPin className="w-3 h-3 mr-1" />
                    {member.location}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;